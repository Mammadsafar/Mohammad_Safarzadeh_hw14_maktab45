$(".menu").click(function(){
    $(this).parent().toggleClass("close");
 });
 
 //Based on: https://dribbble.com/shots/3377940-Home-Budget-App-Interactions